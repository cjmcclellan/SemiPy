"""
Classes for plotting lines
"""
from SemiPy.Plotting.Plotting import Base2DPlot


# class Line2DPlot(Base2DPlot):

