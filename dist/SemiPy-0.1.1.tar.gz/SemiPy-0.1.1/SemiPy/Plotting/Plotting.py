"""
Basic Plotting object
"""

