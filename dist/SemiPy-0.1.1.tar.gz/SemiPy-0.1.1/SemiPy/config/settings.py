"""
Settings module for various user settings
"""
import os

# get the path to the SemiPy directory
SemiPy_Path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
