"""
Testing for transistor models
"""
import unittest
from .Transistor import Transistor


class TestTransistor(unittest.TestCase):

    def test_transistor(self):

        path = '/home/connor/Documents/Stanford_Projects/Extractions/src/SampleData/FETExampleData/nano_patterning.csv'

