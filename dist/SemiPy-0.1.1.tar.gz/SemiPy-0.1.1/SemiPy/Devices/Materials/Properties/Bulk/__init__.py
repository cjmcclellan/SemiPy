from SemiPy.Devices.Materials.Properties.Bulk import Electrical, Thermal, Basic
