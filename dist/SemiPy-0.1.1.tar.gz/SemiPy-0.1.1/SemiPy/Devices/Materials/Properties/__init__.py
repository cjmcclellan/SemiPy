from SemiPy.Devices.Materials.Properties import Bulk, Interfaces
