from SemiPy.Devices.Materials.Properties.Interfaces import Electrical, Thermal
